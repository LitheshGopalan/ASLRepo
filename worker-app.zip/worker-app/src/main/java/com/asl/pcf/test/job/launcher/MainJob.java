package com.asl.pcf.test.job.launcher;


import java.util.Random;
import java.util.StringTokenizer;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class MainJob {
	
	@Value("${words}")
	private String givenWords;
	
	@Value("${length}")
	private int ioLength;

	public void generateSentence() 
	{
		
		System.out.println("Property value (words)  -> "+givenWords.toString());
		System.out.println("Property value (length) -> "+ioLength);
		
		StringTokenizer loTokens = new StringTokenizer(givenWords);
		//System.out.println("Tokens (length) -> "+loTokens.countTokens());
		String[] loWords = new String[loTokens.countTokens()];
		int iKount = 0;
		while (loTokens.hasMoreTokens()) 
		{
			String lsWord = (String) loTokens.nextElement();
			//System.out.println("lsWord -> "+lsWord);
			loWords[iKount] = lsWord;
			iKount++;
		}//eof while
		
		
		for(int i=0; i<ioLength; i++)
		{
			Random loRandom = new Random();
			int liWords = 0;
			StringBuilder loSentenceBuilder = new StringBuilder();
			while (ioLength != liWords)
			{
				int liPos = loRandom.nextInt(loWords.length);
				//System.out.println("liPos -> "+liPos);
				String lsWord = loWords[liPos];
				//System.out.println("lsWord -> "+lsWord);
				loSentenceBuilder.append(lsWord.toUpperCase());
				loSentenceBuilder.append(" ");
				liWords++;
				//System.out.println("lsWord -> "+lsWord);
			}//eof while
			System.out.println("Sentence Derived -> "+loSentenceBuilder.toString());
		}//eof for
	}//eof generateSentence
}


